package uk.ac.swansea.mountainclient;

/**
 * MountainDesc Object Class for client testing purpose.
 * @author Ahmad
 * @sicne 23/04/2021
 * @version 1.0
 */
public class MountainDesc {

    private String name;
    private int height;

    public MountainDesc(String name, int height) {
        this.name = name;
        this.height = height;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the Height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param height the Height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }
}
