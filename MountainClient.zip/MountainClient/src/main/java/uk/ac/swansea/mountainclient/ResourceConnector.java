package uk.ac.swansea.mountainclient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.MediaType;

/**
 * This class tests the rest server and acts as a connector between client and
 * service.
 *
 * @author Ahmad
 * @sicne 23/04/2021
 * @version 1.0
 */
public class ResourceConnector {

    private final Client client = Client.create();
    private WebResource baseURI = client.resource("http://localhost:8080/webapi/myresource");
    private final int okCode = 200;
    /**
     * tests addMountain method of server.
     *
     * @param mountain the new mountain to be added
     * @return String highlighting the result of test
     */
    public String addMount(Mountain mountain) {

        WebResource webTarget = baseURI.path("addmount" + mountain.toString());
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class);
        if (response.getStatus() != okCode) {
            return "GET Failed with code: " + response.getStatus();
        }
        return "Mountain added " + response.getStatus();
    }

    /**
     * tests deleteMountain method of server
     *
     * @param mountain the mountain to be deleted
     * @return String highlighting the result of test
     */
    public String deleteMount(Mountain mountain) {

        WebResource webTarget = baseURI.path("deletemount" + mountain.nameRangeCountryString());
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .delete(ClientResponse.class);
        if (response.getStatus() != okCode) {
            return "GET Failed with code: " + response.getStatus();
        }
        return "Mountain deleted " + response.getStatus();
    }

    /**
     * tests upDateMountain method of server.
     *
     * @param mountain the new mountain to be updated
     * @return String highlighting the result of test
     */
    public String updateHeight(Mountain mountain) {

        WebResource webTarget = baseURI.path("updatemount" + mountain.nameRangeCountryHeightString());
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .post(ClientResponse.class);
        if (response.getStatus() != okCode) {
            return "POST Failed with code: " + response.getStatus();
        }
        return "Height updated " + response.getStatus();
    }

    /**
     * tests getMountainHeight method on server.
     *
     * @param mountain object is used to find its height.
     * @return the height of selected mountain.
     */
    public int getMountHeight(Mountain mountain) {

        WebResource webTarget = baseURI.path("getmountheight" + mountain.nameRangeCountryString());
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        if (response.getStatus() != okCode) {
            System.out.println("Cant get height: ");
            return response.getStatus();
        }
        ObjectMapper mapper = new ObjectMapper();
        int newHeight = 0;
        try {
            newHeight = mapper.readValue(response.getEntity(String.class), new TypeReference<Integer>() {
            });
        } catch (JsonProcessingException ex) {
            Logger.getLogger(ResourceConnector.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return newHeight;
        }

    }

    /**
     * tests the getMountNameHeight method of server
     *
     * @param mountain is the mountain who's name and height is found.
     * @return list of name and height of mountains
     */
    public ArrayList<MountainDesc> getNameHeight(Mountain mountain) {

        WebResource webTarget = baseURI.path("nameheight" + mountain.rangeCountryString());
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        if (response.getStatus() != okCode) {
            System.out.println("GET Failed with error code: " + response.getStatus());
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        ArrayList<MountainDesc> mountains = new ArrayList<>();
        try {
            mountains = mapper.readValue(response.getEntity(String.class), new TypeReference<ArrayList>() {
            });
        } catch (JsonProcessingException ex) {
            Logger.getLogger(ResourceConnector.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return mountains;
        }
    }

    /**
     * tests getMountByCountry method of the server.
     *
     * @param country mountains in this country to be found.
     * @return list of names and height of all mountains in the country.
     */
    public ArrayList<MountainDesc> getByCountry(String country) {

        WebResource webTarget = baseURI.path("mountbycountry/" + country);
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        if (response.getStatus() != okCode) {
            System.out.println("GET Failed with error code: " + response.getStatus());
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        ArrayList<MountainDesc> mountains = new ArrayList<>();
        try {
            mountains = mapper.readValue(response.getEntity(String.class), new TypeReference<ArrayList>() {
            });
        } catch (JsonProcessingException ex) {
            Logger.getLogger(ResourceConnector.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return mountains;
        }
    }

    /**
     * tests the getMountByHemisphere method of server
     *
     * @param hemisphere mountains is this area are searched for.
     * @return list of all mountains in the hemisphere.
     */
    public ArrayList<Mountain> getByHemisphere(String hemisphere) {

        WebResource webTarget = baseURI.path("mountbyhemisphere/" + hemisphere);
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        if (response.getStatus() != okCode) {
            System.out.println("GET Failed with error code: " + response.getStatus());
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        ArrayList<Mountain> mountains = new ArrayList<>();
        try {
            mountains = mapper.readValue(response.getEntity(String.class), new TypeReference<ArrayList>() {
            });
        } catch (JsonProcessingException ex) {
            Logger.getLogger(ResourceConnector.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return mountains;
        }
    }

    /**
     * tests the getMountByHeight method of the server.
     *
     * @param height mountains are compared with this value.
     * @return list of all mountains above the given height.
     */
    public ArrayList<Mountain> getByHeight(int height) {

        WebResource webTarget = baseURI.path("aboveheight/" + String.valueOf(height));
        ClientResponse response = webTarget.type(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
        if (response.getStatus() != okCode) {
            System.out.println("GET Failed with error code: " + response.getStatus());
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        ArrayList<Mountain> mountains = new ArrayList<>();
        try {
            mountains = mapper.readValue(response.getEntity(String.class), new TypeReference<ArrayList>() {
            });
        } catch (JsonProcessingException ex) {
            Logger.getLogger(ResourceConnector.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            return mountains;
        }
    }
}
