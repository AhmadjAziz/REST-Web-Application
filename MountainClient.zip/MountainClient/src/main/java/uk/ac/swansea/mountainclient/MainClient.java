package uk.ac.swansea.mountainclient;

/**
 * This class initiates the client that uses resource connector to test the Rest
 * Service.
 *
 * @author Ahmad
 * @since 23/04/2021
 * @version 1.0
 */
public class MainClient {

    //to pass checkstyle and avoid magic numbers.
    private static final int HEIGHT_FINAL_MOUNT1 = 80000;
    private static final int HEIGHT_FINAL_MOUNT2 = 10000;
    private static final int HEIGHT_FINAL_MOUNT_UPDATED = 95000;

    public static void main(String[] args) {

        ResourceConnector connector = new ResourceConnector();

        Mountain mount1 = new Mountain("Everest", "Himalayas", "Pakistan", HEIGHT_FINAL_MOUNT1, "north");
        Mountain mount2 = new Mountain("BigMount", "Southlands", "GreenLand", HEIGHT_FINAL_MOUNT2, "south");

        System.out.println(connector.addMount(mount1));
        System.out.println(connector.addMount(mount2));

        Mountain mount1Updated = new Mountain("Everest", "Himalayas", "Pakistan", HEIGHT_FINAL_MOUNT_UPDATED, "north");
        System.out.println(connector.updateHeight(mount1Updated));

        System.out.println(connector.getMountHeight(mount1));
        System.out.println(connector.getMountHeight(mount2));

        System.out.println(connector.getNameHeight(mount1));
        System.out.println(connector.getNameHeight(mount2));

        System.out.println(connector.getByCountry("Pakistan"));

        System.out.println(connector.getByHemisphere("north"));

        System.out.println(connector.getByHeight(HEIGHT_FINAL_MOUNT2));

        System.out.println(connector.deleteMount(mount2));

    }
}
