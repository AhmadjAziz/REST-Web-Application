package uk.ac.ahmadaziz;

import jakarta.inject.Singleton;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * This is the rest server that plays around with Mountain and allow different
 * functionalities.
 *
 * @author Ahmad
 * @since 23/04/2021
 * @version 1.0
 */
@Singleton
@Path("myresource")
public class MountainServer {

    private final ArrayList<Mountain> mountainList = new ArrayList<>();
    private ReadWriteLock syncObj = new ReentrantReadWriteLock();

    /**
     * This method adds to the list of mountains only if it does not already
     * exist
     *
     * @param name of mountain
     * @param range of mountain
     * @param country of mountain
     * @param height of mountain
     * @param hemisphere of mountain
     * @return 200 response signifying addition was successful
     */
    @POST
    @Path("/addmount/{name}/{range}/{country}/{height}/{hemisphere}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addMountain(@PathParam("name") String name, @PathParam("range") String range,
            @PathParam("country") String country, @PathParam("height") int height,
            @PathParam("hemisphere") String hemisphere) {

        syncObj.writeLock().lock();
        try {
            //Object made for comparison purpose.
            Mountain newMount = new Mountain(name, range, country, height, hemisphere);
            for (Mountain current : mountainList) {
                //calls method in moiuntain to compare name, country and range.
                if (current.equalsMount(newMount)) {
                    return Response.status(Response.Status.CONFLICT)
                            .entity("Duplicate Item")
                            .type(MediaType.TEXT_PLAIN).build();
                }
            }
            mountainList.add(newMount);
            return Response.status(Response.Status.OK).build();
        } finally {
            syncObj.writeLock().unlock();
        }
    }

    /**
     * This method will delete the mountain off the list if it exists.
     *
     * @param name of mountain
     * @param range of mountain
     * @param country of mountain
     * @return 200 message stating mountain is deleted.
     */
    @DELETE
    @Path("/deletemount/{name}/{range}/{country}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deleteMountain(@PathParam("name") String name, @PathParam("range") String range,
            @PathParam("country") String country) {

        syncObj.writeLock().lock();
        try {
            int randomHeight = 0;
            String randomHemisphere = "";
            //Object made for comparison purpose.
            Mountain newMount = new Mountain(name, range, country, randomHeight, randomHemisphere);

            for (Mountain current : mountainList) {
                //calls method in moiuntain to compare name, country and range.
                if (current.equalsMount(newMount)) {
                    mountainList.remove(current);
                    return Response.status(Response.Status.OK).build();
                }
            }
            return Response.status(Response.Status.NOT_FOUND).entity("Mountain not found")
                    .type(MediaType.TEXT_PLAIN).build();
        } finally {
            syncObj.writeLock().unlock();
        }
    }

    /**
     * this method will update the height of a existing mountain.
     *
     * @param name of mountain
     * @param range of mountain
     * @param country of mountain
     * @param height of mountain
     * @return 200 message states height is updated.
     */
    @POST
    @Path("/updatemount/{name}/{range}/{country}/{height}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response upDateMountain(@PathParam("name") String name, @PathParam("range") String range,
            @PathParam("country") String country, @PathParam("height") int height) {

        syncObj.writeLock().lock();
        try {
            String randomHemisphere = "";
            //Object made for comparison purpose.
            Mountain newMount = new Mountain(name, range, country, height, randomHemisphere);

            for (Mountain current : mountainList) {
                //calls method in moiuntain to compare name, country and range.
                if (current.equalsMount(newMount)) {
                    current.setHeight(height);
                    return Response.status(Response.Status.OK).build();
                }
            }
            return Response.status(Response.Status.NOT_FOUND).entity("Mountain not found")
                    .type(MediaType.TEXT_PLAIN).build();
        } finally {
            syncObj.writeLock().unlock();
        }
    }

    /**
     * This method returns the height of the mountain if it exists in our list.
     *
     * @param name
     * @param range
     * @param country
     * @return the entity height is returned of the mountain with 200 ok
     * message.
     */
    @GET
    @Path("/getmountheight/{name}/{range}/{country}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMountainHeight(@PathParam("name") String name, @PathParam("range") String range,
            @PathParam("country") String country) {

        syncObj.readLock().lock();
        try {
            int randomHeight = 0;
            String randomHemisphere = "";
            //Object made for comparison purpose.
            Mountain newMount = new Mountain(name, range, country, randomHeight, randomHemisphere);

            for (Mountain current : mountainList) {
                //calls method in moiuntain to compare name, country and range.
                if (current.equalsMount(newMount)) {
                    return Response.status(Response.Status.OK).entity(current.getHeight()).build();
                }
            }
            return Response.status(Response.Status.NOT_FOUND).build();
        } finally {
            syncObj.readLock().unlock();
        }
    }

    /**
     * This method will use the range and country to find name and height of
     * mountains.
     *
     * @param range of mountain
     * @param country of mountain
     * @return name and height of all mountains in list as a MountDesc object.
     */
    @GET
    @Path("/nameheight/{range}/{country}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMountNameHeight(@PathParam("range") String range,
            @PathParam("country") String country) {

        syncObj.readLock().lock();
        try {
            ArrayList<MountDesc> mountDescriptionList = new ArrayList<>();

            for (Mountain current : mountainList) {
                if (current.getCountry().equalsIgnoreCase(country)
                        && current.getRange().equalsIgnoreCase(range)) {
                    //create new object that carries a summary of mountain details
                    MountDesc mountdetails = new MountDesc(current.getName(), current.getHeight());
                    mountDescriptionList.add(mountdetails);
                }
            }
            return Response.status(Response.Status.OK).entity(mountDescriptionList).build();
        } finally {
            syncObj.readLock().unlock();
        }
    }

    /**
     * names and height of all mountains in a given country are returned.
     *
     * @param country of mountain
     * @return name and height of all mountains in list as a MountDesc object.
     */
    @GET
    @Path("/mountbycountry/{country}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMountByCountry(@PathParam("country") String country) {

        syncObj.readLock().lock();
        try {
            ArrayList<MountDesc> mountDescriptionList = new ArrayList<>();

            for (Mountain current : mountainList) {
                if (current.getCountry().equalsIgnoreCase(country)) {
                    //create new object that carries a summary of mountain details
                    MountDesc mountdetails = new MountDesc(current.getName(), current.getHeight());
                    mountDescriptionList.add(mountdetails);
                }
            }
            return Response.status(Response.Status.OK).entity(mountDescriptionList).build();
        } finally {
            syncObj.readLock().unlock();
        }
    }

    /**
     * all mountains in a given hemisphere are returned.
     *
     * @param hemisphere of mountain
     * @return list of Mountain in the hemisphere.
     */
    @GET
    @Path("/mountbyhemisphere/{hemisphere}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMountByHemisphere(@PathParam("hemisphere") String hemisphere) {

        syncObj.readLock().lock();
        try {
            ArrayList<Mountain> mountainsByHem = new ArrayList<>();

            for (Mountain current : mountainList) {
                if (current.getHemisphere().equalsIgnoreCase(hemisphere)) {
                    mountainsByHem.add(current);
                }
            }
            return Response.status(Response.Status.OK).entity(mountainsByHem).build();
        } finally {
            syncObj.readLock().unlock();
        }
    }

    /**
     * gets all the mountains that are higher than the provided height.
     *
     * @param height of mountain
     * @return list of Mountain that are above certain height.
     */
    @GET
    @Path("/aboveheight/{height}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getMountByHeight(@PathParam("height") int height) {

        syncObj.readLock().lock();
        try {
            ArrayList<Mountain> mountainsByHeight = new ArrayList<>();

            for (Mountain current : mountainList) {
                if (current.getHeight() > height) {
                    mountainsByHeight.add(current);
                }
            }
            return Response.status(Response.Status.OK).entity(mountainsByHeight).build();
        } finally {
            syncObj.readLock().unlock();
        }
    }
}
