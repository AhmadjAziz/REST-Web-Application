package uk.ac.ahmadaziz;
/**
 *This class contains short version of mountains description. Basically used in 
 * getting object during getter in service.
 * @author Ahmad
 * @since 23/04/2021
 * @version 1.0
 */
public class MountDesc {
    private String name;
    private int height;

    public MountDesc(String name, int height) {
        this.name = name;
        this.height = height;
    }
    public MountDesc(){
        
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }
    
}
