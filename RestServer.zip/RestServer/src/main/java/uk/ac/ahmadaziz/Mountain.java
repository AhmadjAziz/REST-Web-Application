package uk.ac.ahmadaziz;

/**
 * This is the mountain class that has details of what a mountain is made of.
 *
 * @author Ahmad
 * @since 23/04/2021
 * @version 1.0
 */

public class Mountain {

    private String name;
    private String range;
    private String country;
    private String hemisphere;
    private int height;

    public Mountain(String name, String range, String country, int height, String hemisphere) {
        this.name = name;
        this.range = range;
        this.country = country;
        this.hemisphere = hemisphere;
        this.height = height;
    }

    public Mountain() {

    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the range
     */
    public String getRange() {
        return range;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @return the hemisphere
     */
    public String getHemisphere() {
        return hemisphere;
    }

    /**
     * @return the height
     */
    public int getHeight() {
        return height;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @param range the range to set
     */
    public void setRange(String range) {
        this.range = range;
    }

    /**
     * @param country the country to set
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     * @param hemisphere the hemisphere to set
     */
    public void setHemisphere(String hemisphere) {
        this.hemisphere = hemisphere;
    }

    /**
     * @param height the height to set
     */
    public void setHeight(int height) {
        this.height = height;
    }

    public boolean equalsMount(Mountain mountain) {
        return this.country.equalsIgnoreCase(mountain.getCountry())
                && this.range.equalsIgnoreCase(mountain.getRange())
                && this.name.equalsIgnoreCase(mountain.getName());

    }

}
